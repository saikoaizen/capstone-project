import requests
import json
import re
from config import GEMINI_API_KEY, LLM_URL, CRYPTOPANIC_TOKEN

# -------------------------------
# HELPER: CLEAN JSON
# -------------------------------
def clean_json(text):
    """
    Strips markdown code blocks (```json ... ```) and returns a dict.
    """
    try:
        # Remove markdown code blocks
        text = re.sub(r"```json", "", text)
        text = re.sub(r"```", "", text)
        return json.loads(text.strip())
    except Exception as e:
        print(f"⚠ JSON Parse Error: {e}")
        return None

# -------------------------------
# GEMINI NATIVE CALL
# -------------------------------
def call_gemini_llm(prompt):
    if not GEMINI_API_KEY:
        print("⚠ Missing GEMINI_API_KEY in .env")
        return ""

    payload = {
        "contents": [{"parts": [{"text": prompt}]}]
    }
    headers = {
        "Content-Type": "application/json",
        "X-Goog-Api-Key": GEMINI_API_KEY
    }

    try:
        r = requests.post(LLM_URL, headers=headers, json=payload, timeout=20)
        r.raise_for_status()
        data = r.json()
        return data["candidates"][0]["content"][0]["text"]
    except Exception as e:
        print(f"⚠ Gemini API error: {e}")
        return ""

# -------------------------------
# FETCH NEWS
# -------------------------------
def fetch_news():
    if not CRYPTOPANIC_TOKEN:
        return []
        
    try:
        url = f"https://cryptopanic.com/api/v1/posts/?auth_token={CRYPTOPANIC_TOKEN}&kind=news"
        r = requests.get(url, timeout=10)
        data = r.json()
        news = data.get("results", [])
        return [n["title"] for n in news][:5]
    except:
        return []

# -------------------------------
# SENTIMENT ANALYSIS
# -------------------------------
def analyze_sentiment(news):
    if not news:
        return {"score": 0.0, "confidence": 0.0}

    prompt = f"""
    Analyze crypto market sentiment based on these headlines.
    News:
    {chr(10).join(news)}

    Return JSON ONLY:
    {{"score": -1.0 to 1.0, "confidence": 0.0 to 1.0}}
    """
    output = call_gemini_llm(prompt)
    result = clean_json(output)
    return result if result else {"score": 0.0, "confidence": 0.0}

# -------------------------------
# TRADE DECISION
# -------------------------------
def decide(snapshot: dict) -> dict:
    prompt = f"""
    You are a crypto futures trading bot.
    
    CURRENT STATUS:
    Symbol: {snapshot['symbol']}
    Price: {snapshot['price']}
    Position: {snapshot['position']['side']} (Size: {snapshot['position']['size']})
    RSI: {snapshot['indicators']['rsi']:.2f}
    EMA50: {snapshot['indicators']['ema50']:.2f}
    EMA200: {snapshot['indicators']['ema200']:.2f}
    Sentiment Score: {snapshot['sentiment']['score']}

    RULES:
    1. If Position is NONE: Decide to OPEN_LONG, OPEN_SHORT, or HOLD.
    2. If Position is LONG/SHORT: Decide to CLOSE or HOLD.
    3. Do not open opposite trades if a position exists (Close first).
    
    Return JSON ONLY:
    {{
      "action": "OPEN_LONG" | "OPEN_SHORT" | "CLOSE" | "HOLD",
      "reason": "Short explanation",
      "confidence": 0.0 to 1.0
    }}
    """
    output = call_gemini_llm(prompt)
    result = clean_json(output)
    
    # Fallback if AI fails
    if not result:
        return {"action": "HOLD", "confidence": 0}
    return result