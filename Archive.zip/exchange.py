import time
import csv
import os
import math
import pandas as pd
from datetime import datetime
from binance.client import Client
from binance.enums import *
from ta.trend import EMAIndicator
from ta.momentum import RSIIndicator
from config import *
from brain import fetch_news, analyze_sentiment, decide

# =========================
# BINANCE SETUP
# =========================
try:
    client = Client(BINANCE_API_KEY, BINANCE_API_SECRET, testnet=BINANCE_TESTNET)
    print(f"✅ Connected to Binance ({'Testnet' if BINANCE_TESTNET else 'Mainnet'})")
except Exception as e:
    print(f"❌ Connection Error: {e}")
    exit()

# =========================
# LOGGING
# =========================
if not os.path.exists(LOG_FILE):
    with open(LOG_FILE, "w", newline="") as f:
        csv.writer(f).writerow(["time", "symbol", "action", "price", "qty", "pnl", "balance"])

def log_trade(symbol, action, price, qty, pnl, balance):
    with open(LOG_FILE, "a", newline="") as f:
        csv.writer(f).writerow([datetime.utcnow(), symbol, action, price, qty, pnl, balance])

# =========================
# HELPERS: PRECISION
# =========================
# Cache for symbol info
exchange_info = {}

def get_precision(symbol):
    """Fetch quantity and price precision (step size) for a symbol."""
    global exchange_info
    if symbol not in exchange_info:
        info = client.futures_exchange_info()
        for s in info['symbols']:
            exchange_info[s['symbol']] = s
            
    s_info = exchange_info.get(symbol)
    if not s_info: return 3, 2 # Defaults

    qty_precision = 0
    price_precision = 2

    for f in s_info['filters']:
        if f['filterType'] == 'LOT_SIZE':
            step = float(f['stepSize'])
            qty_precision = int(round(-math.log(step, 10), 0))
        if f['filterType'] == 'PRICE_FILTER':
            tick = float(f['tickSize'])
            price_precision = int(round(-math.log(tick, 10), 0))
            
    return qty_precision, price_precision

# =========================
# DATA FETCHING
# =========================
def get_top_movers(limit=SYMBOLS_LIMIT):
    try:
        tickers = client.futures_ticker()
        # Sort by absolute price change percent * volume
        scored = []
        for t in tickers:
            change = abs(float(t['priceChangePercent']))
            vol = float(t['quoteVolume'])
            scored.append((t['symbol'], change * vol))
        
        scored.sort(key=lambda x: x[1], reverse=True)
        return [x[0] for x in scored[:limit]]
    except Exception as e:
        print(f"⚠ Error fetching tickers: {e}")
        return []

def get_market_data(symbol):
    klines = client.futures_klines(symbol=symbol, interval=TIMEFRAME, limit=200)
    df = pd.DataFrame(klines, columns=[
        "time", "open", "high", "low", "close", "volume", 
        "close_time", "q_vol", "trades", "taker_buy_vol", "taker_buy_q_vol", "ignore"
    ])
    df["close"] = df["close"].astype(float)
    df["ema50"] = EMAIndicator(df["close"], window=50).ema_indicator()
    df["ema200"] = EMAIndicator(df["close"], window=200).ema_indicator()
    df["rsi"] = RSIIndicator(df["close"], window=14).rsi()
    return df

def get_current_position(symbol):
    try:
        positions = client.futures_position_information(symbol=symbol)
        for p in positions:
            amt = float(p["positionAmt"])
            if amt != 0:
                side = "LONG" if amt > 0 else "SHORT"
                return {"side": side, "size": amt, "entry": float(p["entryPrice"])}
        return {"side": "NONE", "size": 0.0, "entry": 0.0}
    except Exception as e:
        print(f"⚠ Error fetching position: {e}")
        return {"side": "NONE", "size": 0.0, "entry": 0.0}

def get_usdt_balance():
    try:
        acct = client.futures_account()
        for a in acct['assets']:
            if a['asset'] == 'USDT':
                return float(a['availableBalance'])
    except:
        pass
    return 0.0

# =========================
# EXECUTION
# =========================
def execute_trade(symbol, action, current_pos):
    balance = get_usdt_balance()
    price = float(client.futures_symbol_ticker(symbol=symbol)['price'])
    qty_prec, price_prec = get_precision(symbol)

    if action == "CLOSE":
        if current_pos['size'] == 0: return # Nothing to close
        
        # To close, we buy/sell the exact opposite amount
        side = SIDE_SELL if current_pos['size'] > 0 else SIDE_BUY
        qty = abs(current_pos['size'])
        
        print(f"📉 CLOSING {symbol}: {side} {qty}")
        client.futures_create_order(symbol=symbol, side=side, type=ORDER_TYPE_MARKET, quantity=qty)
        log_trade(symbol, "CLOSE", price, qty, 0, balance) # PnL calc requires more logic, skipping for simple log

    elif action in ["OPEN_LONG", "OPEN_SHORT"]:
        if current_pos['size'] != 0: return # Don't add to position for now

        # Calculate Quantity based on Risk
        # Size = (Balance * Risk * Leverage) / Price
        raw_qty = (balance * RISK_PER_TRADE * LEVERAGE) / price
        qty = round(raw_qty, qty_prec)
        
        if qty == 0:
            print(f"⚠ Position size too small for {symbol}")
            return

        side = SIDE_BUY if action == "OPEN_LONG" else SIDE_SELL
        print(f"📈 OPENING {symbol}: {side} {qty}")
        
        try:
            client.futures_create_order(symbol=symbol, side=side, type=ORDER_TYPE_MARKET, quantity=qty)
            log_trade(symbol, action, price, qty, 0, balance)
        except Exception as e:
            print(f"⚠ Order Failed: {e}")

# =========================
# MAIN LOOP
# =========================
if __name__ == "__main__":
    print("🚀 Bot Started...")
    
    while True:
        try:
            # 1. Get Market Info
            movers = get_top_movers()
            if not movers:
                print("💤 No active symbols found.")
                time.sleep(60)
                continue
            
            target_symbol = movers[0]
            print(f"\n🔍 Analyzing {target_symbol}...")
            
            # 2. Get Data
            df = get_market_data(target_symbol)
            last_row = df.iloc[-1]
            pos_info = get_current_position(target_symbol)
            
            # 3. Analyze Sentiment
            news_headlines = fetch_news()
            sentiment = analyze_sentiment(news_headlines)
            
            # 4. Construct Snapshot
            snapshot = {
                "symbol": target_symbol,
                "price": last_row['close'],
                "indicators": {
                    "rsi": last_row['rsi'],
                    "ema50": last_row['ema50'],
                    "ema200": last_row['ema200']
                },
                "sentiment": sentiment,
                "position": pos_info
            }
            
            # 5. Get AI Decision
            decision = decide(snapshot)
            print(f"🤖 AI Says: {decision['action']} (Conf: {decision.get('confidence',0)}) - {decision.get('reason','')}")
            
            # 6. Execute if confidence is high
            if decision['confidence'] >= 0.7:
                execute_trade(target_symbol, decision['action'], pos_info)
            else:
                print("✋ Confidence too low. Holding.")

            print(f"⏳ Sleeping for {SLEEP_SECONDS}s...")
            time.sleep(SLEEP_SECONDS)

        except KeyboardInterrupt:
            print("\n🛑 Bot stopped by user.")
            break
        except Exception as e:
            print(f"⚠ Critical Loop Error: {e}")
            time.sleep(30)