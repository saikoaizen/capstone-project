import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# =========================
# API KEYS
# =========================
BINANCE_API_KEY = os.getenv("BINANCE_API_KEY")
BINANCE_API_SECRET = os.getenv("BINANCE_API_SECRET")
BINANCE_TESTNET = os.getenv("BINANCE_TESTNET", "True").lower() == "true"
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
CRYPTOPANIC_TOKEN = os.getenv("CRYPTOPANIC_TOKEN")

# =========================
# TRADING SETTINGS
# =========================
SYMBOLS_LIMIT = 5           # Scan top 5 movers
TIMEFRAME = "5m"            # Candle timeframe
LEVERAGE = 3                # Leverage
RISK_PER_TRADE = 0.005      # 0.5% of account per trade
SLEEP_SECONDS = 300         # Run every 5 minutes
LOG_FILE = "trades_log.csv"

# =========================
# LLM SETTINGS
# =========================
# Using Gemini 2.0 Flash
LLM_MODEL = "gemini-2.0-flash" 
LLM_URL = f"https://generativelanguage.googleapis.com/v1beta/models/{LLM_MODEL}:generateContent"